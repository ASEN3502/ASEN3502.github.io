% This example shows how to read in the first matrix-vector pair.
% Modify this script to complete the computation for all three.

A = readmatrix('A1.csv');
x = readmatrix('x1.csv');

b = zeros(length(x)); % Replace with a call to your multiply code.

writematrix(b, 'b1.csv');
