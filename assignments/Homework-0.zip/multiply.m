% Replace this text with your multiply function
