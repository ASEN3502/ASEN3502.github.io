% Start with a small n and work upward. Swap in a faster solver as you write one.
evaluate(1500, 'your.gradescope.email@colorado.edu', @gauss_pivot)
